<?php
$servidor = "localhost";
$usuario = "id8862407_root";
$senha = "maylon";
$dbname = "id8862407_alugavale";

//Criar a conexao
$conn = mysqli_connect($servidor, $usuario, $senha, $dbname);